# Family Circle — setup guide

Family Circle is your family's own private app: a feed for updates and photos, a group chat,
a shared calendar (birthdays repeat every year), and a task list. Family members open it from a
link, sign in with Google or email, and can add it to their phone's home screen like a normal app.

It runs on **Firebase**, Google's free service for apps. The free plan is more than enough for a family.
Setup takes about 30–60 minutes, once. Use a computer for steps 5–6.

---

## 1. Create a Firebase project
1. Go to **https://console.firebase.google.com** and sign in with a Google account.
2. Click **Create a project** (or **Add project**). Name it, for example, `family-circle`.
3. You can turn **off** Google Analytics. Click **Create project**.

## 2. Add a web app and copy its settings
1. On the project home page, click the **web icon `</>`** ("Add app" → Web).
2. Give it a nickname like `Family Circle`. Leave "Firebase Hosting" unticked. Click **Register app**.
3. Firebase shows a block of code with `const firebaseConfig = { ... }`.
4. Open the file **`firebase-config.js`** in this folder (any text editor works, like Notepad or TextEdit)
   and replace each `PASTE_...` value with the matching value from Firebase. Save the file.

   *Tip: if editing the file is hard, send these values to Claude and ask it to fill them in for you.
   They are not secret.*

## 3. Turn on sign-in
1. In the left menu, open **Build → Authentication**, then click **Get started**.
2. Under **Sign-in method**, enable **Email/Password** (first switch only) and click **Save**.
3. Click **Add new provider → Google**, turn it on, pick a support email, and click **Save**.

## 4. Create the database and protect it
1. In the left menu, open **Build → Firestore Database**, then click **Create database**.
2. Choose a location near you, then choose **Start in production mode**. Click **Create**.
3. Open the **Rules** tab. Delete everything there, paste in the whole contents of
   **`firestore.rules`** from this folder, and click **Publish**.

   These rules make sure only members of your family can see your family's posts, chat and photos.

## 5. Put the app online (free)
The easiest way is **Netlify Drop**:
1. On a computer, go to **https://app.netlify.com/drop** and create a free account.
2. Drag this whole **family-circle-app** folder onto the page.
3. After a few seconds you get a link like `https://something-random.netlify.app`.
   In Netlify you can rename it under **Site configuration → Change site name**, for example
   `https://sadri-family.netlify.app`.

To update the app later, open your site in Netlify, go to **Deploys**, and drag the folder in again.

## 6. Allow your new link to sign in
1. Back in Firebase, open **Authentication → Settings → Authorized domains**.
2. Click **Add domain** and enter your Netlify address without `https://`,
   for example `sadri-family.netlify.app`.

## 7. Start your family
1. Open your link on your phone and create an account (or use Google).
2. Choose **Start a new family** and give it a name.
3. Go to the **Family** tab and tap **Share invite link**. Send it to your family by WhatsApp, text or email.
4. When they open the link, they sign in and land straight in your family.

**Add it to the home screen:** on iPhone, open the link in Safari → Share button → **Add to Home Screen**.
On Android, open it in Chrome → menu → **Install app** (or **Add to Home screen**).

---

## Good to know
- **Privacy:** only people who know your family code can join. If someone joins who shouldn't,
  the person who started the family can tap **Remove** next to their name on the Family tab.
  Keep the code within the family.
- **Photos** are resized automatically so they load fast and stay within the free plan.
- **Who can delete what:** everyone can delete their own posts, events and tasks.
  The person who started the family can delete anything and rename the family.
- **Cost:** the free Firebase plan (Spark) covers a family easily. You never need to add a card for this app.
- **Something not working?**
  - "This website address isn't allowed yet" → you missed step 6.
  - You sign in but get "You're no longer in that family" or nothing loads → the rules from step 4
    were not published. Paste them again and click **Publish**.
  - The app says "Almost there" → `firebase-config.js` still has `PASTE_...` values.

## Files in this folder
| File | What it is |
|---|---|
| `index.html`, `style.css`, `app.js` | The app itself |
| `firebase-config.js` | Your Firebase settings (you fill this in) |
| `firestore.rules` | Privacy rules to paste into Firebase |
| `manifest.webmanifest`, `sw.js`, `icons/` | Make it installable on phones and work offline |
