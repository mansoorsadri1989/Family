import { firebaseConfig } from './firebase-config.js';
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import {
  getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult,
  createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, signOut
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  initializeFirestore, persistentLocalCache, doc, getDoc, setDoc, updateDoc, deleteDoc, addDoc,
  collection, query, orderBy, limit, onSnapshot
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

/* ---------------- helpers ---------------- */
const $ = s => document.querySelector(s);
const SCREENS = ['loading', 'config', 'auth', 'family', 'profile'];
function show(name) {
  SCREENS.forEach(s => { $('#screen-' + s).hidden = s !== name; });
  $('#app').hidden = name !== 'app';
}
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v === true) e.setAttribute(k, '');
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  (function add(list) {
    for (const c of list) {
      if (Array.isArray(c)) add(c);
      else if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
  })(kids);
  return e;
}
function svg(markup, cls) { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true'); if (cls) s.setAttribute('class', cls); s.innerHTML = markup; return s; }
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { t.hidden = true; }, 3800); }
function ago(ms) {
  const s = Math.max(1, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return 'just now';
  const m = Math.round(s / 60); if (m < 60) return m + ' min ago';
  const hr = Math.round(m / 60); if (hr < 24) return hr + ' h ago';
  const d = Math.round(hr / 24); if (d < 7) return d + ' d ago';
  return new Date(ms).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
function clock(ms) { return new Date(ms).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); }
function dayLabel(ms) {
  const d = new Date(ms), t = new Date(); const y = new Date(); y.setDate(t.getDate() - 1);
  if (d.toDateString() === t.toDateString()) return 'Today';
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });
}
const parseD = s => { const [y, m, d] = String(s || '').split('-').map(Number); return new Date(y, m - 1, d); };
const today = () => { const t = new Date(); return new Date(t.getFullYear(), t.getMonth(), t.getDate()); };
const YEARLY = ['Birthday', 'Anniversary'];
function nextOcc(ev) {
  const d = parseD(ev.date); if (isNaN(d)) return null;
  if (!YEARLY.includes(ev.kind)) return d;
  const t = today(); let n = new Date(t.getFullYear(), d.getMonth(), d.getDate());
  if (n < t) n = new Date(t.getFullYear() + 1, d.getMonth(), d.getDate());
  return n;
}
const COLORS = ['#1D6B5B', '#C4572E', '#3A62B5', '#9A4FB0', '#B98213', '#2F8A9E', '#B0446E', '#5E7F2A'];
function colorFor(uid) { let n = 0; for (const c of uid || '') n = (n * 31 + c.charCodeAt(0)) >>> 0; return COLORS[n % COLORS.length]; }
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newCode() { const a = new Uint32Array(8); crypto.getRandomValues(a); return Array.from(a, x => CODE_CHARS[x % CODE_CHARS.length]).join(''); }
const cleanCode = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const prettyCode = c => c.length === 8 ? c.slice(0, 4) + '-' + c.slice(4) : c;
function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
function armDelete(btn, label, fn) {
  btn.addEventListener('click', () => {
    if (btn.classList.contains('armed')) { btn.classList.remove('armed'); btn.textContent = label; fn(); return; }
    btn.classList.add('armed'); btn.textContent = 'Tap again to confirm';
    setTimeout(() => { btn.classList.remove('armed'); btn.textContent = label; }, 3000);
  });
}

/* ---------------- setup check ---------------- */
if (!firebaseConfig || !firebaseConfig.apiKey || firebaseConfig.apiKey.startsWith('PASTE')) {
  show('config');
  throw new Error('Firebase is not configured yet: fill in firebase-config.js');
}

const fbApp = initializeApp(firebaseConfig);
const auth = getAuth(fbApp);
let db;
try { db = initializeFirestore(fbApp, { localCache: persistentLocalCache() }); }
catch (e) { db = initializeFirestore(fbApp, {}); }

if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});

/* ---------------- state ---------------- */
const S = {
  user: null, fid: null, family: {}, members: {}, posts: [], chat: [], events: [], tasks: [],
  loaded: {}, tab: 'feed', unsubs: [], editingProfile: false, photo: null
};
const joinParam = cleanCode(new URLSearchParams(location.search).get('join'));
if (joinParam) store('fc-join', joinParam);

const fdoc = (...p) => doc(db, 'families', S.fid, ...p);
const fcol = name => collection(db, 'families', S.fid, name);
const isOwner = () => S.family.createdBy === S.user?.uid;
const nameOf = uid => S.members[uid]?.name || 'Former member';
const roleOf = uid => S.members[uid]?.role || '';
function avatar(uid, sm) {
  const n = nameOf(uid), c = colorFor(uid);
  const el = h('span', { class: 'av' + (sm ? ' sm' : ''), 'aria-hidden': 'true' }, (n.trim().charAt(0) || '?').toUpperCase());
  el.style.borderColor = c; el.style.color = c;
  return el;
}
async function save(fn, okMsg) {
  try { await fn(); if (okMsg) toast(okMsg); return true; }
  catch (e) {
    console.error(e);
    toast(e.code === 'permission-denied' ? "You don't have permission to do that." :
      e.code === 'unavailable' ? "You're offline. It will save when you reconnect." : "That didn't save. Try again.");
    return false;
  }
}

/* ---------------- sign in ---------------- */
let creating = false;
function authErr(msg) { const e = $('#auth-err'); e.textContent = msg; e.hidden = !msg; }
function authMessage(code) {
  return ({
    'auth/invalid-credential': 'That email and password don\'t match. Try again or reset your password.',
    'auth/wrong-password': 'That password is not right.',
    'auth/user-not-found': 'No account with that email. Tap "Create an account".',
    'auth/email-already-in-use': 'That email already has an account. Sign in instead.',
    'auth/weak-password': 'Use at least 6 characters for your password.',
    'auth/invalid-email': 'That email address doesn\'t look right.',
    'auth/too-many-requests': 'Too many tries. Wait a minute and try again.',
    'auth/unauthorized-domain': 'This website address isn\'t allowed yet. Add it in Firebase under Authentication → Settings → Authorized domains.',
    'auth/network-request-failed': 'No internet connection.'
  })[code] || 'Sign-in failed. Try again.';
}
$('#au-toggle').addEventListener('click', () => {
  creating = !creating;
  $('#au-submit').textContent = creating ? 'Create account' : 'Sign in';
  $('#au-toggle').textContent = creating ? 'Have an account? Sign in' : 'New here? Create an account';
  $('#au-pass').autocomplete = creating ? 'new-password' : 'current-password';
  authErr('');
});
$('#email-form').addEventListener('submit', async ev => {
  ev.preventDefault(); authErr('');
  const email = $('#au-email').value.trim(), pass = $('#au-pass').value;
  $('#au-submit').disabled = true;
  try {
    if (creating) await createUserWithEmailAndPassword(auth, email, pass);
    else await signInWithEmailAndPassword(auth, email, pass);
  } catch (e) { authErr(authMessage(e.code)); }
  $('#au-submit').disabled = false;
});
$('#au-reset').addEventListener('click', async () => {
  const email = $('#au-email').value.trim();
  if (!email) { authErr('Type your email above first, then tap "Forgot password".'); return; }
  try { await sendPasswordResetEmail(auth, email); authErr(''); toast('Check your email for a reset link.'); }
  catch (e) { authErr(authMessage(e.code)); }
});
$('#google-btn').addEventListener('click', async () => {
  authErr('');
  const provider = new GoogleAuthProvider();
  const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  try {
    if (standalone) await signInWithRedirect(auth, provider);
    else await signInWithPopup(auth, provider);
  } catch (e) {
    if (['auth/popup-blocked', 'auth/operation-not-supported-in-this-environment', 'auth/cancelled-popup-request'].includes(e.code)) {
      try { await signInWithRedirect(auth, provider); } catch (e2) { authErr(authMessage(e2.code)); }
    } else if (e.code !== 'auth/popup-closed-by-user') authErr(authMessage(e.code));
  }
});
getRedirectResult(auth).catch(e => authErr(authMessage(e.code)));
document.querySelectorAll('[data-signout]').forEach(b => b.addEventListener('click', () => { stopFamily(); signOut(auth); }));

/* ---------------- routing after sign in ---------------- */
onAuthStateChanged(auth, async user => {
  S.user = user;
  if (!user) {
    stopFamily();
    $('#auth-lead').textContent = store('fc-join') ? "You've been invited to a family. Sign in or create an account to join." : 'Sign in to see your family\'s updates, chat, calendar and tasks.';
    if (store('fc-join')) { creating = false; $('#au-toggle').click(); }
    show('auth'); return;
  }
  show('loading');
  try {
    const u = await getDoc(doc(db, 'users', user.uid));
    const fid = u.exists() ? u.data().familyId : null;
    const pending = store('fc-join');
    if (fid) {
      const m = await getDoc(doc(db, 'families', fid, 'members', user.uid));
      if (m.exists()) {
        if (pending && pending !== fid) toast('You already belong to a family. Leave it first to join another.');
        store('fc-join', '');
        return enterFamily(fid, m.data());
      }
    }
    if (pending) $('#join-code').value = prettyCode(pending);
    show('family');
  } catch (e) {
    console.error(e);
    toast('Could not reach the family. Check your connection.');
    show('family');
  }
});

/* ---------------- join or create ---------------- */
function joinErr(msg) { const e = $('#join-err'); e.textContent = msg; e.hidden = !msg; }
async function becomeMember(fid) {
  const uid = S.user.uid;
  await setDoc(doc(db, 'families', fid, 'members', uid), { name: S.user.displayName || '', role: '', joinedAt: Date.now() });
  await setDoc(doc(db, 'users', uid), { familyId: fid });
  store('fc-join', '');
}
$('#join-form').addEventListener('submit', async ev => {
  ev.preventDefault(); joinErr('');
  const fid = cleanCode($('#join-code').value);
  if (fid.length < 6) { joinErr('Family codes have 8 letters and numbers.'); return; }
  try {
    const f = await getDoc(doc(db, 'families', fid));
    if (!f.exists()) { joinErr('No family has that code. Check it with the person who invited you.'); return; }
    await becomeMember(fid);
    S.fid = fid; askProfile(false);
  } catch (e) { console.error(e); joinErr('Could not join. Check your connection and try again.'); }
});
$('#create-form').addEventListener('submit', async ev => {
  ev.preventDefault();
  const name = $('#create-name').value.trim(); if (!name) return;
  try {
    let fid = newCode();
    for (let i = 0; i < 3 && (await getDoc(doc(db, 'families', fid))).exists(); i++) fid = newCode();
    await setDoc(doc(db, 'families', fid), { name, createdBy: S.user.uid, createdAt: Date.now() });
    await becomeMember(fid);
    S.fid = fid; askProfile(false);
  } catch (e) { console.error(e); toast('Could not create the family. Check your connection.'); }
});

/* ---------------- profile ---------------- */
function askProfile(editing) {
  S.editingProfile = editing;
  const me = S.members[S.user.uid] || {};
  $('#pf-name').value = me.name || S.user.displayName || '';
  $('#pf-role').value = me.role || '';
  $('#profile-title').textContent = editing ? 'Your details' : 'Welcome to the family';
  $('#pf-cancel').hidden = !editing;
  show('profile');
}
$('#pf-cancel').addEventListener('click', () => show('app'));
$('#profile-form').addEventListener('submit', async ev => {
  ev.preventDefault();
  const name = $('#pf-name').value.trim(), role = $('#pf-role').value.trim();
  if (!name) return;
  const ok = await save(() => updateDoc(doc(db, 'families', S.fid, 'members', S.user.uid), { name, role }));
  if (!ok) return;
  if (S.editingProfile) { show('app'); toast('Saved.'); }
  else enterFamily(S.fid, { name, role });
});

/* ---------------- live family data ---------------- */
function stopFamily() { S.unsubs.forEach(u => u()); S.unsubs = []; S.fid = null; S.loaded = {}; }
function enterFamily(fid, meDoc) {
  stopFamily();
  S.fid = fid;
  if (!meDoc?.name) { askProfile(false); return; }
  const list = snap => snap.docs.map(d => ({ id: d.id, ...d.data() }));
  const onErr = key => e => { console.error(key, e); S.loaded[key] = true; if (e.code === 'permission-denied') removedFromFamily(); };
  S.unsubs.push(
    onSnapshot(fdoc(), s => { S.family = s.exists() ? s.data() : {}; paintHeader(); paintFamily(); }, onErr('family')),
    onSnapshot(fcol('members'), s => {
      const m = {}; s.docs.forEach(d => { m[d.id] = d.data(); }); S.members = m; S.loaded.members = true;
      if (S.user && !m[S.user.uid] && !s.metadata.fromCache) { removedFromFamily(); return; }
      paintAll();
    }, onErr('members')),
    onSnapshot(query(fcol('posts'), orderBy('at', 'desc'), limit(40)), s => { S.posts = list(s); S.loaded.posts = true; paintFeed(); }, onErr('posts')),
    onSnapshot(query(fcol('chat'), orderBy('at', 'desc'), limit(200)), s => { S.chat = list(s); S.loaded.chat = true; paintChat(); }, onErr('chat')),
    onSnapshot(query(fcol('events'), limit(500)), s => { S.events = list(s); S.loaded.events = true; paintEvents(); }, onErr('events')),
    onSnapshot(query(fcol('tasks'), limit(500)), s => { S.tasks = list(s); S.loaded.tasks = true; paintTasks(); }, onErr('tasks'))
  );
  show('app');
  const hash = location.hash.slice(1);
  setTab(['feed', 'chat', 'events', 'tasks', 'family'].includes(hash) ? hash : S.tab);
}
let removing = false;
async function removedFromFamily() {
  if (removing || !S.user) return; removing = true;
  stopFamily();
  try { await setDoc(doc(db, 'users', S.user.uid), { familyId: null }); } catch (e) { /* ignore */ }
  toast("You're no longer in that family.");
  show('family'); removing = false;
}

/* ---------------- tabs ---------------- */
function setTab(t) {
  S.tab = t;
  ['feed', 'chat', 'events', 'tasks', 'family'].forEach(k => { $('#v-' + k).hidden = k !== t; });
  document.querySelectorAll('.tabs button').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === t)));
  $('#chatbar').hidden = t !== 'chat';
  if (t === 'chat') { markChatSeen(); scrollChat(); } else window.scrollTo(0, 0);
  paintChatDot();
}
document.querySelectorAll('.tabs button').forEach(b => b.addEventListener('click', () => setTab(b.dataset.tab)));
function scrollChat() { requestAnimationFrame(() => window.scrollTo(0, document.body.scrollHeight)); }

/* ---------------- painting ---------------- */
function paintAll() { paintHeader(); paintFeed(); paintChat(); paintEvents(); paintTasks(); paintFamily(); }
function empty(title, sub) { return h('div', { class: 'empty' }, h('b', null, title), sub); }

function paintHeader() {
  $('#fam-name').textContent = S.family.name || 'Our family';
  const n = Object.keys(S.members).length;
  $('#fam-sub').textContent = n === 1 ? 'Just you so far · invite your family' : n + ' people in the circle';
  const me = $('#me-chip'); me.textContent = '';
  if (S.user && S.members[S.user.uid]) me.append(avatar(S.user.uid, true), h('span', null, nameOf(S.user.uid)));
}

function deleteLink(item, coll) {
  if (!(item.by === S.user.uid || isOwner())) return null;
  const b = h('button', { class: 'link', type: 'button' }, 'Delete');
  armDelete(b, 'Delete', () => save(() => deleteDoc(fdoc(coll, item.id))));
  return b;
}

function paintFeed() {
  const box = $('#feed-list'); box.textContent = '';
  if (!S.loaded.posts) return;
  if (!S.posts.length) { box.append(empty('Nothing here yet', 'Post the first update or photo. Everyone in your family will see it.')); return; }
  for (const p of S.posts) {
    const likes = p.likes || [], mine = likes.includes(S.user.uid);
    const like = h('button', {
      class: 'like', type: 'button', 'aria-pressed': String(mine), 'aria-label': mine ? 'Unlike' : 'Like',
      onclick: () => save(() => updateDoc(fdoc('posts', p.id), { likes: mine ? likes.filter(i => i !== S.user.uid) : [...likes, S.user.uid] }))
    }, svg('<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>'), likes.length ? String(likes.length) : 'Like');
    const likedBy = likes.length ? h('span', { class: 'muted small' }, likes.slice(0, 3).map(nameOf).join(', ') + (likes.length > 3 ? ' and ' + (likes.length - 3) + ' more' : '')) : null;
    const photo = p.photo ? h('button', { class: 'photo', type: 'button', 'aria-label': 'Open photo', onclick: () => openPhoto(p.photo) }, h('img', { src: p.photo, alt: 'Photo shared by ' + nameOf(p.by), loading: 'lazy' })) : null;
    box.append(h('article', { class: 'card post' }, avatar(p.by),
      h('div', { class: 'body' },
        h('div', { class: 'who' }, h('b', null, nameOf(p.by)), roleOf(p.by) ? h('span', { class: 'role' }, roleOf(p.by)) : null, h('span', { class: 'when' }, ago(p.at)),
          p.kind && p.kind !== 'Update' ? h('span', { class: 'chip' + (p.kind === 'Good news' ? ' warm' : '') }, p.kind) : null),
        p.text ? h('p', { class: 'text' }, p.text) : null,
        photo,
        h('div', { class: 'acts' }, like, likedBy, h('span', { style: 'margin-left:auto' }, deleteLink(p, 'posts'))))));
  }
}

let lastChatKey = '';
function paintChat() {
  const box = $('#chat-list'); box.textContent = '';
  if (!S.loaded.chat) return;
  if (!S.chat.length) { box.append(empty('No messages yet', 'Say hello. Everyone in your family sees this chat.')); paintChatDot(); return; }
  const msgs = [...S.chat].reverse();
  let lastDay = '', lastBy = '', lastAt = 0;
  for (const m of msgs) {
    const day = dayLabel(m.at);
    if (day !== lastDay) { box.append(h('div', { class: 'daybreak' }, day)); lastDay = day; lastBy = ''; }
    const mine = m.by === S.user.uid, grouped = m.by === lastBy && m.at - lastAt < 5 * 60e3;
    box.append(h('div', { class: 'msg' + (mine ? ' mine' : '') },
      !mine && !grouped ? h('span', { class: 'by' }, nameOf(m.by)) : null,
      h('div', { class: 'bub' }, m.text),
      h('span', { class: 'by' }, clock(m.at))));
    lastBy = m.by; lastAt = m.at;
  }
  const key = msgs.length + ':' + msgs[msgs.length - 1].id;
  if (S.tab === 'chat') { if (key !== lastChatKey) scrollChat(); markChatSeen(); }
  lastChatKey = key;
  paintChatDot();
}
function markChatSeen() { if (S.chat[0]) store('fc-chat-seen-' + S.fid, String(S.chat[0].at)); }
function paintChatDot() {
  const btn = document.querySelector('.tabs button[data-tab="chat"]'); if (!btn) return;
  btn.querySelector('.dot')?.remove();
  const seen = Number(store('fc-chat-seen-' + S.fid) || 0), newest = S.chat[0];
  if (S.tab !== 'chat' && newest && newest.by !== S.user?.uid && newest.at > seen) btn.append(h('span', { class: 'dot', 'aria-label': 'New messages' }));
}

function paintEvents() {
  const box = $('#ev-list'); box.textContent = '';
  if (!S.loaded.events) return;
  const t = today(), up = [], past = [];
  for (const ev of S.events) { const n = nextOcc(ev); if (n) (n >= t ? up : past).push({ ev, n }); }
  up.sort((a, b) => a.n - b.n); past.sort((a, b) => b.n - a.n);
  if (!up.length && !past.length) { box.append(empty('The calendar is empty', 'Add birthdays, school events and get-togethers so no one misses them.')); return; }
  const row = ({ ev, n }) => {
    const days = Math.round((n - t) / 864e5);
    const when = days === 0 ? 'Today' : days === 1 ? 'Tomorrow' : days > 1 && days <= 30 ? 'in ' + days + ' days' : '';
    const bits = [n.toLocaleDateString(undefined, { weekday: 'long', year: n.getFullYear() !== t.getFullYear() ? 'numeric' : undefined })];
    if (ev.time) bits.push(ev.time);
    if (ev.place) bits.push(ev.place);
    const yrs = n.getFullYear() - parseD(ev.date).getFullYear();
    if (ev.kind === 'Birthday' && yrs > 0 && yrs < 120) bits.push('turns ' + yrs);
    if (ev.kind === 'Anniversary' && yrs > 0) bits.push(yrs + (yrs === 1 ? ' year' : ' years'));
    return h('div', { class: 'evrow' },
      h('div', { class: 'leaf' }, h('div', { class: 'm' }, n.toLocaleDateString(undefined, { month: 'short' })), h('div', { class: 'd' }, String(n.getDate()))),
      h('div', { class: 'info' },
        h('div', { class: 't' }, ev.title, ' ', ev.kind && ev.kind !== 'Event' ? h('span', { class: 'chip' + (ev.kind === 'Birthday' ? ' warm' : '') }, ev.kind) : null),
        h('div', { class: 's' }, bits.join(' · '), when ? h('span', { class: 'soon' }, ' · ' + when) : null)),
      deleteLink(ev, 'events'));
  };
  box.append(up.length ? h('div', { class: 'card list' }, up.map(row)) : empty('Nothing coming up', 'Add the next get-together.'));
  if (past.length) box.append(h('details', { class: 'past' }, h('summary', null, 'Earlier (' + past.length + ')'), h('div', { class: 'card list' }, past.slice(0, 15).map(row))));
}

function paintTasks() {
  const sel = $('#task-who'), cur = sel.value, ids = Object.keys(S.members);
  sel.textContent = ''; sel.append(h('option', { value: '' }, 'Anyone'));
  ids.forEach(i => sel.append(h('option', { value: i }, nameOf(i))));
  if (ids.includes(cur)) sel.value = cur;
  const box = $('#task-list'); box.textContent = '';
  if (!S.loaded.tasks) return;
  if (!S.tasks.length) { box.append(empty('No tasks yet', 'Add chores, errands and reminders, then tick them off together.')); return; }
  const open = S.tasks.filter(c => !c.done).sort((a, b) => a.at - b.at);
  const done = S.tasks.filter(c => c.done).sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0));
  const pct = Math.round(100 * done.length / S.tasks.length);
  box.append(h('div', { class: 'card' },
    h('div', { class: 'sect' }, h('h2', null, done.length + ' of ' + S.tasks.length + ' done'), h('span', { class: 'meta' }, open.length ? open.length + ' left' : 'All clear')),
    h('div', { class: 'bar' }, h('i', { style: 'width:' + pct + '%' }))));
  const row = c => {
    const chk = h('button', {
      class: 'chk', type: 'button', role: 'checkbox', 'aria-checked': String(!!c.done), 'aria-label': (c.done ? 'Mark not done: ' : 'Mark done: ') + c.title,
      onclick: () => save(() => updateDoc(fdoc('tasks', c.id), c.done ? { done: false, doneBy: '', doneAt: 0 } : { done: true, doneBy: S.user.uid, doneAt: Date.now() }))
    }, svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>'));
    const sub = c.done ? 'Done by ' + nameOf(c.doneBy) + ' · ' + ago(c.doneAt) : (c.who ? 'For ' + nameOf(c.who) : 'For anyone') + ' · added by ' + nameOf(c.by);
    return h('div', { class: 'chrow' + (c.done ? ' done' : '') }, chk, h('div', { class: 'info' }, h('div', { class: 't' }, c.title), h('div', { class: 's' }, sub)), deleteLink(c, 'tasks'));
  };
  if (open.length) box.append(h('div', { class: 'card list' }, open.map(row)));
  if (done.length) box.append(h('details', { class: 'past', open: !open.length }, h('summary', null, 'Done (' + done.length + ')'), h('div', { class: 'card list' }, done.slice(0, 40).map(row))));
}

function inviteLink() { return location.origin + location.pathname.replace(/index\.html$/, '') + '?join=' + S.fid; }
function paintFamily() {
  if (!S.fid || !S.user) return;
  $('#invite-code').textContent = prettyCode(S.fid);
  $('#invite-link').textContent = inviteLink();
  const ids = Object.keys(S.members).sort((a, b) => (S.members[a].joinedAt || 0) - (S.members[b].joinedAt || 0));
  const list = $('#mem-list'); list.textContent = '';
  for (const i of ids) {
    let remove = null;
    if (isOwner() && i !== S.user.uid) { remove = h('button', { class: 'link', type: 'button' }, 'Remove'); armDelete(remove, 'Remove', () => save(() => deleteDoc(fdoc('members', i)), 'Removed from the family.')); }
    list.append(h('div', { class: 'mem' }, avatar(i),
      h('div', { class: 'info' }, h('div', { class: 't' }, nameOf(i) + (i === S.user.uid ? ' (you)' : '')),
        h('div', { class: 's' }, [roleOf(i) || 'Family member', S.family.createdBy === i ? 'started this family' : ''].filter(Boolean).join(' · '))),
      remove));
  }
  $('#owner-card').hidden = !isOwner();
  const ri = $('#rename-input'); if (document.activeElement !== ri) ri.value = S.family.name || '';
}

/* ---------------- photo ---------------- */
function openPhoto(src) { const v = $('#photo-view'); v.querySelector('img').src = src; v.hidden = false; }
$('#photo-close').addEventListener('click', () => { $('#photo-view').hidden = true; });
$('#photo-view').addEventListener('click', e => { if (e.target.id === 'photo-view') e.currentTarget.hidden = true; });

function shrinkImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const attempt = (max, q) => {
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        return c.toDataURL('image/jpeg', q);
      };
      let out = attempt(1280, 0.72);
      if (out.length > 850000) out = attempt(1024, 0.62);
      if (out.length > 850000) out = attempt(800, 0.55);
      out.length > 890000 ? reject(new Error('too big')) : resolve(out);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('unreadable')); };
    img.src = url;
  });
}
$('#post-photo').addEventListener('change', async e => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  try {
    S.photo = await shrinkImage(f);
    const box = $('#post-photo-preview'); box.textContent = '';
    box.append(h('img', { src: S.photo, alt: 'Photo to post' }),
      h('button', { class: 'btn small', type: 'button', onclick: () => { S.photo = null; box.hidden = true; box.textContent = ''; } }, 'Remove'));
    box.hidden = false;
  } catch (err) { toast("That photo couldn't be added. Try a different one."); }
});

/* ---------------- forms ---------------- */
$('#post-form').addEventListener('submit', async ev => {
  ev.preventDefault();
  const text = $('#post-text').value.trim();
  if (!text && !S.photo) { toast('Write something or add a photo first.'); return; }
  const btn = $('#post-submit'); btn.disabled = true;
  const data = { by: S.user.uid, text, kind: $('#post-kind').value, at: Date.now(), likes: [] };
  if (S.photo) data.photo = S.photo;
  const ok = await save(() => addDoc(fcol('posts'), data));
  btn.disabled = false;
  if (ok) { $('#post-text').value = ''; S.photo = null; const b = $('#post-photo-preview'); b.hidden = true; b.textContent = ''; }
});
$('#chat-form').addEventListener('submit', async ev => {
  ev.preventDefault();
  const inp = $('#chat-input'), text = inp.value.trim(); if (!text) return;
  inp.value = '';
  const ok = await save(() => addDoc(fcol('chat'), { by: S.user.uid, text, at: Date.now() }));
  if (!ok) inp.value = text; else scrollChat();
});
$('#ev-form').addEventListener('submit', async ev => {
  ev.preventDefault();
  const title = $('#ev-title').value.trim(), date = $('#ev-date').value; if (!title || !date) return;
  const ok = await save(() => addDoc(fcol('events'), {
    by: S.user.uid, title, date, time: $('#ev-time').value, place: $('#ev-place').value.trim(), kind: $('#ev-kind').value, at: Date.now()
  }), 'Added to the calendar.');
  if (ok) { $('#ev-form').reset(); $('#ev-add').open = false; }
});
$('#task-form').addEventListener('submit', async ev => {
  ev.preventDefault();
  const title = $('#task-title').value.trim(); if (!title) return;
  const ok = await save(() => addDoc(fcol('tasks'), { by: S.user.uid, title, who: $('#task-who').value, done: false, doneBy: '', doneAt: 0, at: Date.now() }));
  if (ok) $('#task-title').value = '';
});
$('#rename-form').addEventListener('submit', ev => {
  ev.preventDefault();
  const name = $('#rename-input').value.trim(); if (!name) return;
  save(() => updateDoc(fdoc(), { name }), 'Family name saved.');
});
$('#edit-me').addEventListener('click', () => askProfile(true));
armDelete($('#leave-btn'), 'Leave this family', async () => {
  const uid = S.user.uid, fid = S.fid;
  stopFamily();
  await save(async () => { await deleteDoc(doc(db, 'families', fid, 'members', uid)); await setDoc(doc(db, 'users', uid), { familyId: null }); }, 'You left the family.');
  show('family');
});

/* ---------------- invite ---------------- */
$('#share-btn').addEventListener('click', async () => {
  const text = 'Join our family on Family Circle. Family code: ' + prettyCode(S.fid);
  if (navigator.share) {
    try { await navigator.share({ title: 'Family Circle', text, url: inviteLink() }); } catch (e) { /* cancelled */ }
  } else copyInvite();
});
async function copyInvite() {
  try { await navigator.clipboard.writeText(inviteLink()); toast('Invite link copied.'); }
  catch (e) {
    const r = document.createRange(); r.selectNodeContents($('#invite-link'));
    const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
    toast('Select the link and copy it.');
  }
}
$('#copy-btn').addEventListener('click', copyInvite);

/* ---------------- install ---------------- */
let installEvent = null;
addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvent = e; $('#install-btn').hidden = false; });
$('#install-btn').addEventListener('click', async () => {
  if (!installEvent) return;
  installEvent.prompt(); await installEvent.userChoice; installEvent = null; $('#install-btn').hidden = true;
});
addEventListener('appinstalled', () => { $('#install-btn').hidden = true; toast('Family Circle is on your home screen.'); });
